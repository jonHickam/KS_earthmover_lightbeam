-- Table [ks].[AssessmentRequestDescriptor] --
CREATE TABLE [ks].[AssessmentRequestDescriptor] (
    [AssessmentRequestDescriptorId] [INT] NOT NULL,
    CONSTRAINT [AssessmentRequestDescriptor_PK] PRIMARY KEY CLUSTERED (
        [AssessmentRequestDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[CollegeCareerTypeDescriptor] --
CREATE TABLE [ks].[CollegeCareerTypeDescriptor] (
    [CollegeCareerTypeDescriptorId] [INT] NOT NULL,
    CONSTRAINT [CollegeCareerTypeDescriptor_PK] PRIMARY KEY CLUSTERED (
        [CollegeCareerTypeDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[CourseDeliveryTypeDescriptor] --
CREATE TABLE [ks].[CourseDeliveryTypeDescriptor] (
    [CourseDeliveryTypeDescriptorId] [INT] NOT NULL,
    CONSTRAINT [CourseDeliveryTypeDescriptor_PK] PRIMARY KEY CLUSTERED (
        [CourseDeliveryTypeDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[CourseOfferingExtension] --
CREATE TABLE [ks].[CourseOfferingExtension] (
    [LocalCourseCode] [NVARCHAR](60) NOT NULL,
    [SchoolId] [INT] NOT NULL,
    [SchoolYear] [SMALLINT] NOT NULL,
    [SessionName] [NVARCHAR](60) NOT NULL,
    [CourseCredits] [DECIMAL](5, 2) NULL,
    [CourseSequence] [INT] NULL,
    [CourseTotalSequence] [INT] NULL,
    [CourseDeliveryTypeDescriptorId] [INT] NULL,
    [CourseProgramTypeDescriptorId] [INT] NULL,
    [CollegeCareerTypeDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [CourseOfferingExtension_PK] PRIMARY KEY CLUSTERED (
        [LocalCourseCode] ASC,
        [SchoolId] ASC,
        [SchoolYear] ASC,
        [SessionName] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[CourseOfferingExtension] ADD CONSTRAINT [CourseOfferingExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[CourseProgramTypeDescriptor] --
CREATE TABLE [ks].[CourseProgramTypeDescriptor] (
    [CourseProgramTypeDescriptorId] [INT] NOT NULL,
    CONSTRAINT [CourseProgramTypeDescriptor_PK] PRIMARY KEY CLUSTERED (
        [CourseProgramTypeDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[CourseStatusDescriptor] --
CREATE TABLE [ks].[CourseStatusDescriptor] (
    [CourseStatusDescriptorId] [INT] NOT NULL,
    CONSTRAINT [CourseStatusDescriptor_PK] PRIMARY KEY CLUSTERED (
        [CourseStatusDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[CTECertificationEarnedDescriptor] --
CREATE TABLE [ks].[CTECertificationEarnedDescriptor] (
    [CTECertificationEarnedDescriptorId] [INT] NOT NULL,
    CONSTRAINT [CTECertificationEarnedDescriptor_PK] PRIMARY KEY CLUSTERED (
        [CTECertificationEarnedDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[FundingSourceDescriptor] --
CREATE TABLE [ks].[FundingSourceDescriptor] (
    [FundingSourceDescriptorId] [INT] NOT NULL,
    CONSTRAINT [FundingSourceDescriptor_PK] PRIMARY KEY CLUSTERED (
        [FundingSourceDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[GradeExtension] --
CREATE TABLE [ks].[GradeExtension] (
    [BeginDate] [DATE] NOT NULL,
    [GradeTypeDescriptorId] [INT] NOT NULL,
    [GradingPeriodDescriptorId] [INT] NOT NULL,
    [GradingPeriodSchoolYear] [SMALLINT] NOT NULL,
    [GradingPeriodSequence] [INT] NOT NULL,
    [LocalCourseCode] [NVARCHAR](60) NOT NULL,
    [SchoolId] [INT] NOT NULL,
    [SchoolYear] [SMALLINT] NOT NULL,
    [SectionIdentifier] [NVARCHAR](255) NOT NULL,
    [SessionName] [NVARCHAR](60) NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [CollegeCreditEarned] [DECIMAL](4, 2) NULL,
    [InstructionalMinutesCompleted] [DECIMAL](7, 2) NULL,
    [WorkBasedLearningDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [GradeExtension_PK] PRIMARY KEY CLUSTERED (
        [BeginDate] ASC,
        [GradeTypeDescriptorId] ASC,
        [GradingPeriodDescriptorId] ASC,
        [GradingPeriodSchoolYear] ASC,
        [GradingPeriodSequence] ASC,
        [LocalCourseCode] ASC,
        [SchoolId] ASC,
        [SchoolYear] ASC,
        [SectionIdentifier] ASC,
        [SessionName] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[GradeExtension] ADD CONSTRAINT [GradeExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[ImmigrantStudentDescriptor] --
CREATE TABLE [ks].[ImmigrantStudentDescriptor] (
    [ImmigrantStudentDescriptorId] [INT] NOT NULL,
    CONSTRAINT [ImmigrantStudentDescriptor_PK] PRIMARY KEY CLUSTERED (
        [ImmigrantStudentDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[KSAtRiskEligibilityDescriptor] --
CREATE TABLE [ks].[KSAtRiskEligibilityDescriptor] (
    [KSAtRiskEligibilityDescriptorId] [INT] NOT NULL,
    CONSTRAINT [KSAtRiskEligibilityDescriptor_PK] PRIMARY KEY CLUSTERED (
        [KSAtRiskEligibilityDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[LanguageInstructionProgramTypeDescriptor] --
CREATE TABLE [ks].[LanguageInstructionProgramTypeDescriptor] (
    [LanguageInstructionProgramTypeDescriptorId] [INT] NOT NULL,
    CONSTRAINT [LanguageInstructionProgramTypeDescriptor_PK] PRIMARY KEY CLUSTERED (
        [LanguageInstructionProgramTypeDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[MilitaryConnectedStudentDescriptor] --
CREATE TABLE [ks].[MilitaryConnectedStudentDescriptor] (
    [MilitaryConnectedStudentDescriptorId] [INT] NOT NULL,
    CONSTRAINT [MilitaryConnectedStudentDescriptor_PK] PRIMARY KEY CLUSTERED (
        [MilitaryConnectedStudentDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[NeglectedDelinquentStudentDescriptor] --
CREATE TABLE [ks].[NeglectedDelinquentStudentDescriptor] (
    [NeglectedDelinquentStudentDescriptorId] [INT] NOT NULL,
    CONSTRAINT [NeglectedDelinquentStudentDescriptor_PK] PRIMARY KEY CLUSTERED (
        [NeglectedDelinquentStudentDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[PRAtRiskEligibilityDescriptor] --
CREATE TABLE [ks].[PRAtRiskEligibilityDescriptor] (
    [PRAtRiskEligibilityDescriptorId] [INT] NOT NULL,
    CONSTRAINT [PRAtRiskEligibilityDescriptor_PK] PRIMARY KEY CLUSTERED (
        [PRAtRiskEligibilityDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[QualifiedFor504Descriptor] --
CREATE TABLE [ks].[QualifiedFor504Descriptor] (
    [QualifiedFor504DescriptorId] [INT] NOT NULL,
    CONSTRAINT [QualifiedFor504Descriptor_PK] PRIMARY KEY CLUSTERED (
        [QualifiedFor504DescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[SchoolExtension] --
CREATE TABLE [ks].[SchoolExtension] (
    [SchoolId] [INT] NOT NULL,
    [DateClosed] [DATE] NULL,
    [DateOpened] [DATE] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [SchoolExtension_PK] PRIMARY KEY CLUSTERED (
        [SchoolId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[SchoolExtension] ADD CONSTRAINT [SchoolExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[SectionEducator] --
CREATE TABLE [ks].[SectionEducator] (
    [EducatorElectronicMailAddress] [NVARCHAR](128) NOT NULL,
    [LocalCourseCode] [NVARCHAR](60) NOT NULL,
    [SchoolId] [INT] NOT NULL,
    [SchoolYear] [SMALLINT] NOT NULL,
    [SectionIdentifier] [NVARCHAR](255) NOT NULL,
    [SessionName] [NVARCHAR](60) NOT NULL,
    [EducatorFirstName] [NVARCHAR](75) NULL,
    [EducatorMiddleName] [NVARCHAR](75) NULL,
    [EducatorLastSurname] [NVARCHAR](75) NULL,
    [Discriminator] [NVARCHAR](128) NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    [LastModifiedDate] [DATETIME2] NOT NULL,
    [Id] [UNIQUEIDENTIFIER] NOT NULL,
    CONSTRAINT [SectionEducator_PK] PRIMARY KEY CLUSTERED (
        [EducatorElectronicMailAddress] ASC,
        [LocalCourseCode] ASC,
        [SchoolId] ASC,
        [SchoolYear] ASC,
        [SectionIdentifier] ASC,
        [SessionName] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[SectionEducator] ADD CONSTRAINT [SectionEducator_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO
ALTER TABLE [ks].[SectionEducator] ADD CONSTRAINT [SectionEducator_DF_Id] DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [ks].[SectionEducator] ADD CONSTRAINT [SectionEducator_DF_LastModifiedDate] DEFAULT (getdate()) FOR [LastModifiedDate]
GO

-- Table [ks].[SnackPack] --
CREATE TABLE [ks].[SnackPack] (
    [StateStudentId] [NVARCHAR](32) NOT NULL,
    [MostRecentSchool] [NVARCHAR](75) NULL,
    [AccountabilitySchool] [NVARCHAR](75) NULL,
    [SchoolEntryDate] [DATE] NULL,
    [SchoolExitWithdrawalDate] [DATE] NULL,
    [GradeLevel] [NVARCHAR](75) NULL,
    [CumulativeDaysAttended] [DECIMAL](4, 1) NULL,
    [Homeless] [NVARCHAR](10) NULL,
    [Immigrant] [NVARCHAR](10) NULL,
    [KansasAtRiskProgramParticipation] [NVARCHAR](75) NULL,
    [ESOLBilingualProgramEntryDate] [NVARCHAR](10) NULL,
    [FirstLanguage] [NVARCHAR](75) NULL,
    [ESOLBilingualProgramParticipationCode] [NVARCHAR](75) NULL,
    [NeglectedDelinquentStudent] [NVARCHAR](10) NULL,
    [TitleIParticipation] [NVARCHAR](10) NULL,
    [LunchProgramEligibilityAtRiskFunding] [NVARCHAR](75) NULL,
    [ResidenceDistrict] [NVARCHAR](75) NULL,
    [Qualifiedfor504] [NVARCHAR](10) NULL,
    [PrimaryDisabilityIndicator] [NVARCHAR](10) NULL,
    [GiftedStudentIndicator] [NVARCHAR](10) NULL,
    [Discriminator] [NVARCHAR](128) NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    [LastModifiedDate] [DATETIME2] NOT NULL,
    [Id] [UNIQUEIDENTIFIER] NOT NULL,
    CONSTRAINT [SnackPack_PK] PRIMARY KEY CLUSTERED (
        [StateStudentId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[SnackPack] ADD CONSTRAINT [SnackPack_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO
ALTER TABLE [ks].[SnackPack] ADD CONSTRAINT [SnackPack_DF_Id] DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [ks].[SnackPack] ADD CONSTRAINT [SnackPack_DF_LastModifiedDate] DEFAULT (getdate()) FOR [LastModifiedDate]
GO

-- Table [ks].[StudentAssessmentExtension] --
CREATE TABLE [ks].[StudentAssessmentExtension] (
    [AssessmentIdentifier] [NVARCHAR](60) NOT NULL,
    [Namespace] [NVARCHAR](255) NOT NULL,
    [StudentAssessmentIdentifier] [NVARCHAR](60) NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [ProctorStaffUSI] [INT] NULL,
    [AssessmentRequestDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentAssessmentExtension_PK] PRIMARY KEY CLUSTERED (
        [AssessmentIdentifier] ASC,
        [Namespace] ASC,
        [StudentAssessmentIdentifier] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentAssessmentExtension] ADD CONSTRAINT [StudentAssessmentExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentEducationOrganizationAssociationCTE] --
CREATE TABLE [ks].[StudentEducationOrganizationAssociationCTE] (
    [CertificationTermDescriptorId] [INT] NOT NULL,
    [CTECertificationDateEarned] [DATE] NOT NULL,
    [CTECertificationEarnedDescriptorId] [INT] NOT NULL,
    [EducationOrganizationId] [INT] NOT NULL,
    [GraduationYear] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentEducationOrganizationAssociationCTE_PK] PRIMARY KEY CLUSTERED (
        [CertificationTermDescriptorId] ASC,
        [CTECertificationDateEarned] ASC,
        [CTECertificationEarnedDescriptorId] ASC,
        [EducationOrganizationId] ASC,
        [GraduationYear] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentEducationOrganizationAssociationCTE] ADD CONSTRAINT [StudentEducationOrganizationAssociationCTE_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentEducationOrganizationAssociationExtension] --
CREATE TABLE [ks].[StudentEducationOrganizationAssociationExtension] (
    [EducationOrganizationId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [DistrictOfResidence] [NVARCHAR](10) NULL,
    [ImmigrantStudentDescriptorId] [INT] NULL,
    [NeglectedDelinquentStudentDescriptorId] [INT] NULL,
    [MilitaryConnectedStudentDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentEducationOrganizationAssociationExtension_PK] PRIMARY KEY CLUSTERED (
        [EducationOrganizationId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentEducationOrganizationAssociationExtension] ADD CONSTRAINT [StudentEducationOrganizationAssociationExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentEducationOrganizationAssociationKSAtRiskEligibility] --
CREATE TABLE [ks].[StudentEducationOrganizationAssociationKSAtRiskEligibility] (
    [CertificationTermDescriptorId] [INT] NOT NULL,
    [CTECertificationDateEarned] [DATE] NOT NULL,
    [EducationOrganizationId] [INT] NOT NULL,
    [GraduationYear] [INT] NOT NULL,
    [KSAtRiskEligibilityDescriptorId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentEducationOrganizationAssociationKSAtRiskEligibility_PK] PRIMARY KEY CLUSTERED (
        [CertificationTermDescriptorId] ASC,
        [CTECertificationDateEarned] ASC,
        [EducationOrganizationId] ASC,
        [GraduationYear] ASC,
        [KSAtRiskEligibilityDescriptorId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentEducationOrganizationAssociationKSAtRiskEligibility] ADD CONSTRAINT [StudentEducationOrganizationAssociationKSAtRiskEligibility_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentEducationOrganizationAssociationPRAtRiskEligibility] --
CREATE TABLE [ks].[StudentEducationOrganizationAssociationPRAtRiskEligibility] (
    [EducationOrganizationId] [INT] NOT NULL,
    [PRAtRiskEligibilityDescriptorId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentEducationOrganizationAssociationPRAtRiskEligibility_PK] PRIMARY KEY CLUSTERED (
        [EducationOrganizationId] ASC,
        [PRAtRiskEligibilityDescriptorId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentEducationOrganizationAssociationPRAtRiskEligibility] ADD CONSTRAINT [StudentEducationOrganizationAssociationPRAtRiskEligibility_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentEducationOrganizationAssociationTransportation] --
CREATE TABLE [ks].[StudentEducationOrganizationAssociationTransportation] (
    [EducationOrganizationId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [MilesTransported] [DECIMAL](3, 1) NULL,
    [TransportationFTE] [DECIMAL](2, 1) NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentEducationOrganizationAssociationTransportation_PK] PRIMARY KEY CLUSTERED (
        [EducationOrganizationId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentEducationOrganizationAssociationTransportation] ADD CONSTRAINT [StudentEducationOrganizationAssociationTransportation_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentKPATProgramAssociation] --
CREATE TABLE [ks].[StudentKPATProgramAssociation] (
    [BeginDate] [DATE] NOT NULL,
    [EducationOrganizationId] [INT] NOT NULL,
    [ProgramEducationOrganizationId] [INT] NOT NULL,
    [ProgramName] [NVARCHAR](60) NOT NULL,
    [ProgramTypeDescriptorId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    CONSTRAINT [StudentKPATProgramAssociation_PK] PRIMARY KEY CLUSTERED (
        [BeginDate] ASC,
        [EducationOrganizationId] ASC,
        [ProgramEducationOrganizationId] ASC,
        [ProgramName] ASC,
        [ProgramTypeDescriptorId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[StudentKPPProgramAssociation] --
CREATE TABLE [ks].[StudentKPPProgramAssociation] (
    [BeginDate] [DATE] NOT NULL,
    [EducationOrganizationId] [INT] NOT NULL,
    [ProgramEducationOrganizationId] [INT] NOT NULL,
    [ProgramName] [NVARCHAR](60) NOT NULL,
    [ProgramTypeDescriptorId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    CONSTRAINT [StudentKPPProgramAssociation_PK] PRIMARY KEY CLUSTERED (
        [BeginDate] ASC,
        [EducationOrganizationId] ASC,
        [ProgramEducationOrganizationId] ASC,
        [ProgramName] ASC,
        [ProgramTypeDescriptorId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Table [ks].[StudentLanguageInstructionProgramAssociationExtension] --
CREATE TABLE [ks].[StudentLanguageInstructionProgramAssociationExtension] (
    [BeginDate] [DATE] NOT NULL,
    [EducationOrganizationId] [INT] NOT NULL,
    [ProgramEducationOrganizationId] [INT] NOT NULL,
    [ProgramName] [NVARCHAR](60) NOT NULL,
    [ProgramTypeDescriptorId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [USInitialSchoolEntryDate] [DATE] NULL,
    [FundingSourceDescriptorId] [INT] NULL,
    [LanguageInstructionProgramTypeDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentLanguageInstructionProgramAssociationExtension_PK] PRIMARY KEY CLUSTERED (
        [BeginDate] ASC,
        [EducationOrganizationId] ASC,
        [ProgramEducationOrganizationId] ASC,
        [ProgramName] ASC,
        [ProgramTypeDescriptorId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentLanguageInstructionProgramAssociationExtension] ADD CONSTRAINT [StudentLanguageInstructionProgramAssociationExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentSchoolAssociationExtension] --
CREATE TABLE [ks].[StudentSchoolAssociationExtension] (
    [EntryDate] [DATE] NOT NULL,
    [SchoolId] [INT] NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [LocalEducationAgencyEntryDate] [DATE] NOT NULL,
    [StateEntryDate] [DATE] NOT NULL,
    [SchoolEntryDate] [DATE] NOT NULL,
    [MembershipDays] [DECIMAL](4, 1) NULL,
    [MinutesEnrolled] [INT] NULL,
    [CreditsRequiredToGraduate] [DECIMAL](9, 3) NULL,
    [CTEContactMinutes] [DECIMAL](3, 0) NULL,
    [IndividualPlanOfStudy] [BIT] NULL,
    [QualifiedFor504DescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentSchoolAssociationExtension_PK] PRIMARY KEY CLUSTERED (
        [EntryDate] ASC,
        [SchoolId] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentSchoolAssociationExtension] ADD CONSTRAINT [StudentSchoolAssociationExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[StudentSectionAssociationExtension] --
CREATE TABLE [ks].[StudentSectionAssociationExtension] (
    [BeginDate] [DATE] NOT NULL,
    [LocalCourseCode] [NVARCHAR](60) NOT NULL,
    [SchoolId] [INT] NOT NULL,
    [SchoolYear] [SMALLINT] NOT NULL,
    [SectionIdentifier] [NVARCHAR](255) NOT NULL,
    [SessionName] [NVARCHAR](60) NOT NULL,
    [StudentUSI] [INT] NOT NULL,
    [CourseStatusDescriptorId] [INT] NULL,
    [CreateDate] [DATETIME2] NOT NULL,
    CONSTRAINT [StudentSectionAssociationExtension_PK] PRIMARY KEY CLUSTERED (
        [BeginDate] ASC,
        [LocalCourseCode] ASC,
        [SchoolId] ASC,
        [SchoolYear] ASC,
        [SectionIdentifier] ASC,
        [SessionName] ASC,
        [StudentUSI] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [ks].[StudentSectionAssociationExtension] ADD CONSTRAINT [StudentSectionAssociationExtension_DF_CreateDate] DEFAULT (getdate()) FOR [CreateDate]
GO

-- Table [ks].[WorkBasedLearningDescriptor] --
CREATE TABLE [ks].[WorkBasedLearningDescriptor] (
    [WorkBasedLearningDescriptorId] [INT] NOT NULL,
    CONSTRAINT [WorkBasedLearningDescriptor_PK] PRIMARY KEY CLUSTERED (
        [WorkBasedLearningDescriptorId] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

